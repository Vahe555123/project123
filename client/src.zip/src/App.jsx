import { MyProject } from "./project"

function App() {

  return (
    <>
      <MyProject />
    </>
  )
}

export default App
