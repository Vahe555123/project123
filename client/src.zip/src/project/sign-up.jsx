import { useState } from "react"

export const SignUp = () => {
    const [value, setValue] = useState({})
    const [isRegister, setIsRegister] = useState(false)
    const handleChange = (e) => {
        const { name, value } = e.target
        setValue(pr => {
            return { ...pr, [name]: value }
        })
    }
    const addUser = async () => {
        try {
            const req = await fetch('http://localhost:3001/api/auth/register', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(value)
            })
            const res = await req.json()
            console.log(res);
            if (req.ok) {
                setIsRegister(true)
            }
        } catch (error) {
            console.log(error);
        }
    }
    const verifyUser = async () => {
        try {
            const req = await fetch('http://localhost:3001/api/auth/verify', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ code: value.code, email: value.email })
            })
            const res = await req.json()
            console.log(res);
        } catch (error) {
            console.log(error);
        }
    }
    return (
        <>
            <input disabled={isRegister} name="name" onChange={handleChange} />
            <input disabled={isRegister} name="lastName" onChange={handleChange} />
            <input disabled={isRegister} name="email" onChange={handleChange} />
            <input disabled={isRegister} name="password" onChange={handleChange} />
            <button disabled={isRegister} onClick={addUser}>sign up</button>
            {isRegister && <>
                <input name="code" onChange={handleChange} />
                <button onClick={verifyUser}>verify</button>
            </>}
        </>
    )
}