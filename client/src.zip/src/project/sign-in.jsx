import { useState } from "react"
export const SignIn = () => {
    const [value, setValue] = useState({})
    const handleChange = (e) => {
        const { name, value } = e.target
        setValue(pr => {
            return { ...pr, [name]: value }
        })
    }
    const loginUser = async () => {
        try {
            const req = await fetch('http://localhost:3001/api/auth/login', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(value)
            })
            const res = await req.json()
            console.log(res);
            if(req.ok){
                localStorage.setItem('token', res.token)
            }
        } catch (error) {
            console.log(error);
        }
    }
    return (
        <>
        <h1>LOGIN</h1>
            <input name="email" onChange={handleChange} />
            <input  name="password" onChange={handleChange} />
            <button  onClick={loginUser}>sign in</button>
        </>
    )
}