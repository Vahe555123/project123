import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import {  SignUp } from "./sign-up"
import { SignIn } from "./sign-in"
export const MyProject = () => {
    return (
        <Router>
            <Routes>
                <Route path="sign-up" element={<SignUp />} />
                <Route path="sign-in" element={<SignIn />} />
                <Route />
            </Routes>
        </Router>
    )
}